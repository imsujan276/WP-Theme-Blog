<?php 
	function sg_admin_menu(){
		add_menu_page(
			'My Theme Options',
			'Theme Options',
			'edit_theme_options',
			'sg_theme_opts',
			'sg_theme_opts_page'
		);
	}