<?php 
	function sg_theme_opts_page(){
		//get theme options from the database of field 'sg_opts'
		$theme_opts 	=	get_option('sg_opts');
	?>
		<div class="wrap">
			<div class="panel panel-success">
				<div class="panel-heading">
					<h3 class="panel-title"><?php _e('My Blog Theme Setting','firstblog'); ?> </h3>
				</div>
				<div class="panel-body">
					<form method="post" action="admin-post.php" >

						<?php 
							if(isset($_GET['status']) && $_GET['status'] == 1){
								?>
								<div class="alert alert-success"> Settings updated sucessfully!</div>
								<?php
							}
						?>

						<!-- Prevent XSS attact -->
						<input type="hidden" name="action" value="sg_save_options">
						<?php wp_nonce_field('sg_option_verify'); ?>

						<h4><?php _e('Social Icons','firstblog'); ?></h4>
						<div class="form-group">
							<label><?php _e('Facebook','firstblog'); ?> </label>
							<input type="text" name="sg_inputFacebook" class="form-control" value="<?php echo $theme_opts['facebook']; ?>">
						</div>
						<div class="form-group">
							<label><?php _e('Twitter','firstblog'); ?> </label>
							<input type="text" name="sg_inputTwitter" class="form-control" value="<?php echo $theme_opts['twitter']; ?>">
						</div>
						<div class="form-group">
							<label><?php _e('Youtube','firstblog'); ?> </label>
							<input type="text" name="sg_inputYoutube" class="form-control" value="<?php echo $theme_opts['youtube']; ?>">
						</div>
						<h4><?php _e('Logo','firstblog'); ?></h4>
						<div class="form-group">
							<label><?php _e('Logo Type','firstblog'); ?> </label>
							<select class="form-control" name="sg_inputLogoType">
								<option value="1"><?php _e('Site Name','firstblog'); ?> </option>
								<option value="2" <?php echo $theme_opts['logo_type'] == 2 ? 'SELECTED' : '' ?>><?php _e('Logo','firstblog'); ?> </option>
							</select>
						</div>
						<div class="input-group">
							<input type="text" name="sg_inputLogoImg" id="sg_inputLogoImg" class="form-control" placeholder="Logo Image" value="<?php echo $theme_opts['logo_img']; ?>">
							<span class="btn btn-primary" type="button" id="sg_uploadLogoImgBtn">
								<?php _e('Upload','firstblog'); ?>
							</span>
						</div>
						<h4><?php _e('Footer','firstblog'); ?></h4>
						<div class="form-group">
							<label><?php _e('Footer Text (HTML allowed)','firstblog'); ?> </label>
							<textarea name="sg_inputFooter" class="form-control"> <?php echo stripslashes_deep($theme_opts['footer']); ?> </textarea>
						</div>
						<div class="form-group">
							<input type="submit" name="sg_inputSubmit" class="btn btn-success" value="UPDATE">
						</div>
					</form>
				</div>
			</div>
		</div>
	<?php
	}