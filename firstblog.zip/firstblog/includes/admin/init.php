<?php 
	function sg_admin_init(){
		include('enqueue.php');

		add_action('admin_enqueue_scripts', 'sg_admin_enqueue');

		//to save admin form data, action should always be admin-post.php and the form should hook admin_post_$actionName where $actionName = name of the hidden field named 'action'
		add_action('admin_post_sg_save_options','sg_save_options');  

	}