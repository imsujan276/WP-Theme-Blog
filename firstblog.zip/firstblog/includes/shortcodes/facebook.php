<?php 
	function sg_fb_shortcode( $atts, $content='Like Us in Facebook'){
		$theme_opts = get_option('sg_opts');

		$atts	=	shortcode_atts(array(
			'page' => $theme_opts['facebook']
		), $atts);
		return "<a href='http://facebook.com/".$atts['page'] ."'class='btn bg-facebook'>".do_shortcode($content)."</a>";
	}

	function sg_icon_shortcode($atts){
		return "<i class='fa fa-".$atts['icon']."'></i>";
	}