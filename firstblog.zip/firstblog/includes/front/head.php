<?php  
	function sg_head(){
		?>
		<style type="text/css">
			.navbar.navbar-expand-lg, .card .card-header .bg-primary{
				background-color: <?php echo get_theme_mod('header_bg_color','#161616'); ?> !important;
			}
		</style>
		<?php
	}
?>