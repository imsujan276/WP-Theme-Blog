<?php
 function sg_enqueue(){
 	wp_register_style('sg_home', get_template_directory_uri().'/assets/css/blog-home.css');
 	wp_register_style('sg_bootstrap', get_template_directory_uri().'/assets/vendor/bootstrap/css/bootstrap.min.css');
 	wp_register_style('sg_fontAwesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css');

 	wp_enqueue_style('sg_home');
 	wp_enqueue_style('sg_bootstrap');
 	wp_enqueue_style('sg_fontAwesome');

 	
	// fifth parameter is set to true if need to display in the footer
 	wp_register_script('sg_jquery',get_template_directory_uri().'/assets/vendor/jquery/jquery.min.js', array(), false,true);
 	wp_register_script('sg_bootstrap_js',get_template_directory_uri().'/assets/vendor/bootstrap/js/bootstrap.bundle.min.js', array(), false,true);

 	//wp_enqueue_script('jquery');
 	wp_enqueue_script('sg_jquery');
 	wp_enqueue_script('sg_bootstrap_js');
 }