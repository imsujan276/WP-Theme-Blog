<?php
	function sg_widgets(){
		register_sidebar(array(
			'name'	=>	__('My First Theme Sidebar','firstblog'),
			'id'	=>	'sg_sidebar',
			'description'	=> __('Sidebar for my first blog','firstblog'),
			'before_widget'	=>	'<div id="%1$s" class="card my-4 %2$s">',
			'after_widget'	=>	'</div></div>',
			'before_title'	=>	'<h5 class="card-header">',
			'after_title'	=>	'</h5><div class="card-body">'
		));
	}