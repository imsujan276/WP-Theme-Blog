<?php 
	if(is_active_sidebar('sg_sidebar')){
		dynamic_sidebar('sg_sidebar');
	}