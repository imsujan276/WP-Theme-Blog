

<?php get_header(); ?>

    <!-- Page Content -->
    <div class="container">

      <div class="row">

        <!-- Blog Entries Column -->
        <div class="col-md-12">

          <article class="card">
            <div class="card-content">
              <h1 class="text-center text-danger">
                <i class="fa fa-frown-o"></i> <br>
                <?php _e("404! Page Not Found!","firstblog"); ?>
              </h1>
            </div>
          </article>

          

        </div>


      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Footer -->
<?php get_footer(); ?>