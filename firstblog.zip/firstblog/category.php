

<?php get_header(); ?>

    <!-- Page Content -->
    <div class="container">

      <div class="row">

        <!-- Blog Entries Column -->
        <div class="col-md-8">

          <h1 class="my-4">Page Heading
            <small>Secondary Text</small>
          </h1>

          <?php 
          	if(have_posts()){
          		while(have_posts()){
          			the_post();
          			?>

          			<!-- Blog Post -->
			          <div class="card mb-4">

			          	<?php 
			          		if(has_post_thumbnail()){

			          			the_post_thumbnail('full', array('class'=> 'card-img-top')); 
			          		}
			          		
			            ?>

			            <div class="card-body">
			              <h2 class="card-title">
			              	<a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a> 

			              	</h2>
			              <p class="card-text">
			              	<?php the_excerpt(); ?>
			              </p>

			              <a href="<?php the_permalink(); ?>" class="btn btn-primary">Read More &rarr;</a>
			            </div>
			            <div class="card-footer text-muted">
			              Posted on <?php the_time('l, F j, Y'); ?> 
			              by
			              <a href="<?php the_author_link(); ?> "> 
			              	<?php the_author(); ?> 
			              </a> 
			              <small> in <?php the_category(','); ?></small>
			            </div>
			          </div>
			       <?php
          		}
          	}
           ?>

          <!-- Pagination -->
          <ul class="pagination justify-content-center mb-4">
            <li class="page-item">
            	<?php previous_posts_link('<p class="page-link"> <- Older</p>'); ?>
              <!-- <a class="page-link" href="#">&larr; Older</a> -->
            </li>
            <li class="page-item">
              <?php next_posts_link('<p class="page-link">Newer -></p>'); ?>
            </li>
          </ul>

        </div>

        <!-- Sidebar Widgets Column -->
        <div class="col-md-4">

          <!-- Side Widget -->
              <?php get_sidebar(); ?>
          

        </div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Footer -->
<?php get_footer(); ?>