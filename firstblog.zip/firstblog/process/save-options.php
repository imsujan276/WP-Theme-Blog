<?php 
	
	function sg_save_options(){

		if(!current_user_can('edit_theme_options')){
			wp_die(__('You are Not WELCOMED.'));
		}

		check_admin_referer('sg_option_verify');

		$opts = get_option('sg_opts');
		$opts['facebook']	=	sanitize_text_field($_POST['sg_inputFacebook']);
		$opts['twitter']	=	sanitize_text_field($_POST['sg_inputTwitter']);
		$opts['youtube']	=	sanitize_text_field($_POST['sg_inputYoutube']);
		$opts['logo_type']	=	absint($_POST['sg_inputLogoType']);
		$opts['logo_img']	=	esc_url_raw($_POST['sg_inputLogoImg']);
		$opts['footer']		=	$_POST['sg_inputFooter'];

		update_option('sg_opts',$opts);
		wp_redirect(admin_url('admin.php?page=sg_theme_opts&status=1'));

	}