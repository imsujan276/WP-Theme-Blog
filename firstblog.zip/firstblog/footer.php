
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">
        	<?php
			  $theme_opts = get_option('sg_opts');    
			  echo stripslashes_deep($theme_opts['footer']);
			?>
        </p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <?php wp_footer(); ?>

  </body>

</html>
