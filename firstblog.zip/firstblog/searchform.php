

            <h5 class="card-header">Search</h5>
            <div class="card-body">
            	<form role="search" method="get" id="searchform" class="searchform" action ="<?php echo home_url('/'); ?>">
					<div class="input-group">
						<input type="text" placeholder="Type in to Search" class="input-sm form-control" name="s" id="search" value="<?php the_search_query(); ?>">
						<span class="input-group-btn">
							<button type="button" class="btn btn-sm btn-primary ">
								SEARCH
							</button>
						</span>
					</div>
					
				</form>
            </div>
          