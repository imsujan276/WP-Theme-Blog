jQuery(function($){
	var frame 	=	wp.media({
		title: 	'Select or Upload Logo',
		button: 	{
			text: 	'Use This Media'
			},
		multiple: 	false, 
	}); 

	$("#sg_uploadLogoImgBtn").click(function(e){
		e.preventDefault();
		frame.open();
	});

	frame.on('select', function(){
		var attachment = frame.state().get('selection').first().toJSON();
		$("#sg_inputLogoImg").val(attachment.url);
	});
});