<?php
  $theme_opts = get_option('sg_opts');    
?>

<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <?php wp_head(); ?>

  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container"> 
        <a class="navbar-brand" href="<?php echo home_url('/'); ?>">
          <?php 
            if($theme_opts['logo_type'] == 2){
              ?>
              <img src="<?php echo $theme_opts['logo_img']; ?>" width="50px" title="<?php bloginfo('name'); ?>">
            <?php
            }else{
                bloginfo('name');
            }
            ?>
        
      </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">

        	<?php
        		wp_nav_menu(array(
        			'theme_location' => 'primary',
        			'container'		=>	false,
        			'menu_class'	=>	'navbar-nav ml-auto',
        		));
        	?>

          <ul class="navbar-nav ml-auto">
            <?php
              if(!empty($theme_opts['facebook'])){
                ?>
                  <li class="nav-item active">
                    <a class="nav-link" href="https://facebook.com/<?php echo $theme_opts['facebook']; ?>">
                      <i class="fa fa-facebook"></i>
                    </a>
                  </li>
                <?php
              }
            ?>
            <?php
              if(!empty($theme_opts['twitter'])){
                ?>
                  <li class="nav-item active">
                    <a class="nav-link" href="https://twitter.com/<?php echo $theme_opts['twitter']; ?>">
                      <i class="fa fa-twitter"></i>
                    </a>
                  </li>
                <?php
              }
            ?>
            <?php
              if(!empty($theme_opts['youtube'])){
                ?>
                  <li class="nav-item active">
                    <a class="nav-link" href="https://youtube.com/user/<?php echo $theme_opts['youtube']; ?>">
                      <i class="fa fa-youtube"></i>
                    </a>
                  </li>
                <?php
              }
            ?>
          </ul> 

        </div>
      </div>
    </nav>